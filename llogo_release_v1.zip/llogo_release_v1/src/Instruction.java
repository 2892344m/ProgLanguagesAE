public abstract class Instruction {

}
