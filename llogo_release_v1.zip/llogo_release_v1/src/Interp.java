import ast.*;

public class Interp {
    public Interp() {

    }

    public InterpResult interpExpr(Expr e) {
        throw new RuntimeException("interpExpr (Interp.java): fill me in");
    }


}
