import ast.*;

public class Desugar {

    public static Expr desugarExpr(Expr expr) {
        throw new RuntimeException("desugarExpr (Desugar.java): fill me in");
    }

}
